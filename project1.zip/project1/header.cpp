/**including header files for importing the respective classes*/
#include "header.h"
/**Method for displaying of values of roll,pitch and yaw*/
void rpy::display() { cout << x << "\t" << y << "\t" << z << "\t"; }

double rpy::getvalue(string s) {
  if (s == "x")
    return x;
  else if (s == "y")
    return y;
  else if (s == "z")
    return z;
}
/**Displaying of subsequent values for Light class*/

void Light::display() { cout << intensity << endl; }
