var searchData=
[
  ['getvalue',['getvalue',['../classsensor.html#a7a2b89ae3c969964699b02ea0a9d1a25',1,'sensor::getvalue()'],['../classrpy.html#a84e0a61e89385aba619bc4372130fe58',1,'rpy::getvalue()']]],
  ['getvaluelux',['getvaluelux',['../classsensor.html#aa0f4655c51fa3bd7e3a5c0ba55232d6b',1,'sensor::getvaluelux()'],['../class_light.html#aabcc8f3e1ad83d1e5ec5c2768a849098',1,'Light::getvaluelux()']]]
];
