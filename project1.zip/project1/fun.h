#include "header.h"

void DisplayReading(vector<double>);

void LightCond(json);
