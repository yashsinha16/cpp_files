======================================
**************************************

1)Download the zip file and extract it in any directory of your choice
2)Open terminal at the location of file
3)run the subsequent commands
	a)make
	b)if this doesn't work run -> make clean
	c)now run -> make run
4)You will get the results showing roll,pitch and yaw (in radians)

Doxygen Report:-
Go to the extracted html file and access any html file to know more.